./setup SNIa_ddt -objdir=build/object_snia_hotwd2d -2d -auto -nxb=32 -nyb=32 +newMpole +cylindrical -maxblocks=100 -with-unit=Particles/ParticlesMain 
