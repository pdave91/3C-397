#ifndef UT_SYSMEMMALLINFO_H
#define UT_SYSMEMMALLINFO_H

#include "ut_sysMemCTypes.h"
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

#if defined (__GLIBC__) || defined (__GNU_LIBRARY__)
# define FLASH_SUPPORT_MALLINFO
#endif

#ifdef FLASH_SUPPORT_MALLINFO
# define MALLINFO_STATS 5
#else
# define MALLINFO_STATS 0
#endif

typedef struct mallinfo_info_t
{
  int verbosity;
  const char *description;
} mallinfo_info_t;

static const struct mallinfo_info_t mallinfo_info[] =
{
  {
    0,
    "heap use       (MB):"
  },
  {
    1,
    "mmap use       (MB):"
  },
  {
    1,
    "sbrk use       (MB):"
  },
  {
    1,
    "malloc in use  (MB):"
  },
  {
    1,
    "malloc in free (MB):"
  }
};

int ut_sysMemMallinfoNumStats(int verbosity);
void ut_sysMemMallinfo(meminfo_t *meminfo, int meminfoSize, int verbosity);

#endif
