#include "ut_sysMemBGKernel.h"

int ut_sysMemBGKernelNumStats(int verbosity)
{
  int numMeasurements, i;
  numMeasurements = 0;
#ifdef __bg__
  for (i=0; i<BGKERNEL_STATS; ++i) {
    if (opmap[i].verbosity <= verbosity) {
      ++numMeasurements;
    }
  }
#endif
  return numMeasurements;
}

void ut_sysMemBGKernel(meminfo_t *meminfo, int meminfoSize, int verbosity)
{
#ifdef __bg__
# ifdef __PPC64__
  uint64_t memory_size = 0;
# else
  uint32_t memory_size = 0;
# endif
  const double convertToMB = 1.0 / (1024.0 * 1024.0);
  int numMeasurements, i, j;

  numMeasurements = 0;
  for (i=0; i<BGKERNEL_STATS; ++i) {
    if (opmap[i].verbosity <= verbosity) {
      ++numMeasurements;
      if (numMeasurements <= meminfoSize) {
	j = numMeasurements - 1;
	Kernel_GetMemorySize(opmap[i].op, &memory_size);
	meminfo[j].measurement = memory_size * convertToMB;
	meminfo[j].description = opmap[i].description;
      }
    }
  }
#endif
}
