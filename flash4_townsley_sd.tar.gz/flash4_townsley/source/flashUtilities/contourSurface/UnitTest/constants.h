

#define NDIM 3
#define PI 3.1415926535897932384

#define LOW 1
#define HIGH 2
#define MDIM 3
#define IAXIS 1
#define JAXIS 2
#define KAXIS 3
