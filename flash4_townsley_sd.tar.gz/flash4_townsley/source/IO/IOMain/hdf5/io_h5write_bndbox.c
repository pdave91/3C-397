
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include "mangle_names.h"
#include <hdf5.h>
#include "hdf5_flash.h"
/*#include <mpi.h>*/
#include "Flash.h"
#include "constants.h"


int Driver_abortFlashC(char* message);


/* xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx */

void FTOC(io_h5write_bndbox)(int* myPE,
                       hid_t* file_identifier,
                       double* bnd_box,
                       int* local_blocks,
                       int* total_blocks,
                       int* global_offset)
{

  /* The bnd_box dataset will be output as
     for example in 2d xcoord lowerleft, xcoord upper right,
     ycoord lowerleft, ycoord upper right
   
  */

  hid_t dataspace, dataset, memspace, dxfer_template;
  herr_t status;

  int rank;
  hsize_t dimens_3d[3];

  hsize_t start_3d[3];
  hsize_t stride_3d[3], count_3d[3];

  int ierr;

  /* set the dimensions of the dataset */
  rank = 3;
  dimens_3d[0] = *total_blocks;
  dimens_3d[1] = MDIM;
  dimens_3d[2] = 2;  

  dataspace = H5Screate_simple(rank, dimens_3d, NULL);



  if ((*myPE == MASTER_PE) && (*global_offset != 0)) {
    dataset = H5Dopen(*file_identifier, "bounding box"); 
    if(dataset < 0) {
      Driver_abortFlashC("Error: H5Dopen io_h5write_bndbox\n");
    }
  }else {
    /* create the dataset */
    dataset = H5Dcreate(*file_identifier, "bounding box", 
                  H5T_NATIVE_DOUBLE, dataspace, H5P_DEFAULT);
    if(dataset < 0) {
      Driver_abortFlashC("Error: H5Dcreate io_h5write_bndbox\n");
    }
  }


  if(*local_blocks > 0){


    /* create the hyperslab -- this will differ on the different processors */
    start_3d[0] = (hsize_t) (*global_offset);
    start_3d[1] = 0;
    start_3d[2] = 0;
    
    stride_3d[0] = 1;
    stride_3d[1] = 1;
    stride_3d[2] = 1;
    
    count_3d[0] = (hsize_t) (*local_blocks);
    count_3d[1] = MDIM;
    count_3d[2] = 2;
    
    status = H5Sselect_hyperslab(dataspace, H5S_SELECT_SET, start_3d, 
				 stride_3d, count_3d, NULL);
    
    /* create the memory space */
    /* what is this should it be local or total blocks here???*/
    rank = 3;
    dimens_3d[0] = *local_blocks;
    dimens_3d[1] = MDIM;
    dimens_3d[2] = 2;
    
    memspace = H5Screate_simple(rank, dimens_3d, NULL);
    
    start_3d[0] = 0;
    start_3d[1] = 0;
    start_3d[2] = 0;
    
    stride_3d[0] = 1;
    stride_3d[1] = 1;
    stride_3d[2] = 1;
    
    count_3d[0] = *local_blocks;
    count_3d[1] = MDIM;
    count_3d[2] = 2;
    
    ierr = H5Sselect_hyperslab(memspace, H5S_SELECT_SET,
			       start_3d, stride_3d, count_3d, NULL);
    
    /*in parallel, we should set the mode*/
    dxfer_template = H5Pcreate(H5P_DATASET_XFER);
#ifdef IO_HDF5_PARALLEL
    if(HDF5_MODE == COLLECTIVE)
      H5Pset_dxpl_mpio(dxfer_template, H5FD_MPIO_COLLECTIVE);
#endif

    /* write the data */
    status = H5Dwrite(dataset, H5T_NATIVE_DOUBLE, memspace, dataspace, 
		      dxfer_template, bnd_box);
    
    
    if(status < 0) {
      printf("%s\n","Unable to write bnd_box");
      Driver_abortFlashC("Unable to write bnd_box");
    }

    H5Pclose(dxfer_template);
    H5Sclose(memspace);
  }

 
  H5Sclose(dataspace);
  H5Dclose(dataset);

}



