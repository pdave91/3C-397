
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include "mangle_names.h"
#include <hdf5.h>
#include "hdf5_flash.h"
/*#include <mpi.h>*/
#include "Flash.h"
#include "constants.h"


int Driver_abortFlashC(char* message);

/* xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx */

void FTOC(io_h5write_procnumber)(int* myPE,
                         hid_t* file_identifier,
                         int procnumber[],
                         int* local_blocks,
                         int* total_blocks,
                         int* global_offset)
{
  hid_t dataspace, dataset, memspace, dxfer_template;
  herr_t status;

  int rank;
  hsize_t dimens_1d;

  hsize_t start_1d;
  hsize_t stride_1d, count_1d;

  /* set the dimensions of the dataset */
  rank = 1;
  dimens_1d = *total_blocks;
  
  dataspace = H5Screate_simple(rank, &dimens_1d, NULL);


  if ((*myPE == MASTER_PE) && (*global_offset != 0)) {
    dataset = H5Dopen(*file_identifier, "processor number"); 
    if(dataset < 0) {
      Driver_abortFlashC("Error: H5Dopen io_h5write_lrefine\n");
    }
    
  }else {
    /* create the dataset */
    dataset = H5Dcreate(*file_identifier, "processor number", H5T_NATIVE_INT,
                  dataspace, H5P_DEFAULT);
  }    

  
  if(*local_blocks > 0) {
    /* create the hyperslab -- this will differ on the different processors */
    start_1d = (hsize_t) (*global_offset);
    stride_1d = 1;
    count_1d = (hsize_t) (*local_blocks);
    
    status = H5Sselect_hyperslab(dataspace, H5S_SELECT_SET, &start_1d, 
				 &stride_1d, &count_1d, NULL);
    
    if(status < 0) {
      printf("%s\n","Unable to select hyperslab for processor number");
      Driver_abortFlashC("Unable to select hyperslab for processor number");
    }
    
    
    /* create the memory space */
    dimens_1d = *local_blocks;
    memspace = H5Screate_simple(rank, &dimens_1d, NULL);
    
    /*in parallel, we should set the mode*/
    dxfer_template = H5Pcreate(H5P_DATASET_XFER);
#ifdef IO_HDF5_PARALLEL
    if(HDF5_MODE == COLLECTIVE)
      H5Pset_dxpl_mpio(dxfer_template, H5FD_MPIO_COLLECTIVE);
#endif

    /* write the data */
    status = H5Dwrite(dataset, H5T_NATIVE_INT, memspace, dataspace, 
		      dxfer_template, procnumber);
    
    if(status < 0) {
      printf("%s\n","Unable to write processor number");
      Driver_abortFlashC("Unable to write processor number");
    }

    H5Pclose(dxfer_template);
    H5Sclose(memspace);
  }
  
  H5Sclose(dataspace);
  H5Dclose(dataset);
  
}



