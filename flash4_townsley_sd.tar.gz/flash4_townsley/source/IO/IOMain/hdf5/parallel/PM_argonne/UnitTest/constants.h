#define MASTER_PE 0
#define MAX_STRING_LENGTH 80
#define CENTER 2
#define FACEX 3
#define FACEY 4
#define FACEZ 5
#define SCRATCH 1
