#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include "mangle_names.h"
#include <hdf5.h>
#include "hdf5_flash.h"
/*#include <mpi.h>*/
#include "Flash.h"
#include "constants.h"


int Driver_abortFlashC(char* message);

/* writes boundbox data in single precision */

/* xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx */

void FTOC(io_h5write_bndbox_sp)(int* myPE,
                        hid_t* file_identifier,
                        float* bnd_box,
                        int* local_blocks,
                        int* total_blocks,
                        int* global_offset)
{
  hid_t dataspace, dataset, memspace;
  herr_t status;

  int rank;
  hsize_t dimens_3d[3];

  hsize_t start_3d[3];
  hsize_t stride_3d[3], count_3d[3];

  int ierr;

  /* set the dimensions of the dataset */
  rank = 3;
  dimens_3d[0] = *total_blocks;
  dimens_3d[1] = MDIM;
  dimens_3d[2] = 2;

  dataspace = H5Screate_simple(rank, dimens_3d, NULL);


  if ((*myPE == MASTER_PE) && (*global_offset != 0)) {
    dataset = H5Dopen(*file_identifier, "bounding box"); 
    if(dataset < 0) {
      Driver_abortFlashC("Error: H5Dopen io_h5write_bndbox_sp\n");
    }
  }else {
    /* create the dataset */
    dataset = H5Dcreate(*file_identifier, "bounding box", 
                  H5T_NATIVE_FLOAT, dataspace, H5P_DEFAULT);
    if(dataset < 0) {
      Driver_abortFlashC("Error: H5Dcreate io_h5write_bndbox_sp\n");
    }
  }


  /* create the hyperslab -- this will differ on the different processors */
  start_3d[0] = (hsize_t) (*global_offset);
  start_3d[1] = 0;
  start_3d[2] = 0;

  stride_3d[0] = 1;
  stride_3d[1] = 1;
  stride_3d[2] = 1;

  count_3d[0] = (hsize_t) (*local_blocks);
  count_3d[1] = MDIM;
  count_3d[2] = 2;

  status = H5Sselect_hyperslab(dataspace, H5S_SELECT_SET, start_3d, 
                        stride_3d, count_3d, NULL);

  if (status < 0){
    printf("Error: Unable to select hyperslab for bnd box dataspace\n");
    Driver_abortFlashC("Error: Unable to select hyperslab for bnd box dataspace\n");
  }

  /* create the memory space */
  rank = 3;
  dimens_3d[0] = *total_blocks;
  dimens_3d[1] = MDIM;
  dimens_3d[2] = 2;

  memspace = H5Screate_simple(rank, dimens_3d, NULL);

  start_3d[0] = 0;
  start_3d[1] = 0;
  start_3d[2] = 0;

  stride_3d[0] = 1;
  stride_3d[1] = 1;
  stride_3d[2] = 1;

  count_3d[0] = *local_blocks;
  count_3d[1] = MDIM;
  count_3d[2] = 2;

  ierr = H5Sselect_hyperslab(memspace, H5S_SELECT_SET,
                             start_3d, stride_3d, count_3d, NULL);

  if (ierr < 0){
    printf("Error: Unable to select hyperslab for bnd box memspace\n");
    Driver_abortFlashC("Error: Unable to select hyperslab for bnd box memspace\n");
  }

  /* write the data */
  status = H5Dwrite(dataset, H5T_NATIVE_FLOAT, memspace, dataspace, 
                H5P_DEFAULT, bnd_box);

  if (status < 0){
    printf("Error: Unable to write bnd_box\n");
    Driver_abortFlashC("Error: Unable to write bnd_box\n");
  }

  H5Sclose(memspace); 
  H5Sclose(dataspace);
  H5Dclose(dataset);

}
