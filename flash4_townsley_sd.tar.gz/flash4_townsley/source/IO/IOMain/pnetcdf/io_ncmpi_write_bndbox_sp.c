#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>
#include <pnetcdf.h>
#include "mangle_names.h"
#include <mpi.h>
#include "Flash.h"
#include "constants.h"


int Driver_abortFlashC(char* message);

/*writes bounding box data in single precision */

/* xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx */

void FTOC(io_ncmpi_write_bndbox_sp)(int* file_identifier,
                            int* varid,
                            float* bnd_box,
                            int* local_blocks,
                            int* total_blocks,
                            int* global_offset)
{
  int ncid, status;

  MPI_Offset start_3d[3], count_3d[3];

  ncid = *file_identifier;

  start_3d[0] = (MPI_Offset) (*global_offset);
  start_3d[1] = 0;
  start_3d[2] = 0;

      
  count_3d[0] = (MPI_Offset) (*local_blocks);
  count_3d[1] = MDIM; 
  count_3d[2] = 2;


  status = ncmpi_put_vara_float_all(ncid, *varid, start_3d, count_3d, bnd_box);
  if (status < 0){
    printf("Error: ncmpi_put_vara_float_all, bnd_box\n");
    Driver_abortFlashC("Error: ncmpi_put_vara_float_all, bnd_box\n");
    
  }
  

#ifdef DEBUG_IO
        if (status != NC_NOERR)  handle_error(status);
#endif

}


