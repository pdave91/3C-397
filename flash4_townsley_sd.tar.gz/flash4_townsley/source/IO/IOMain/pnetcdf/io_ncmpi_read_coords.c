#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <pnetcdf.h>
#include "mangle_names.h"
#include <mpi.h>
#include <assert.h>
#include "Flash.h"
#include "constants.h"


int Driver_abortFlashC(char* message);

/* read block center coordinate data from parallel netcdf checkpoint file */

/* xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx */

void FTOC(io_ncmpi_read_coords)(int* file_identifier, /* file handler */
                       int* varid,      /* id for coord variable */
                       double* coordinates,  /* returned read data */
                       int* local_blocks,   /* local blocks on proc to read */
                       int* total_blocks,   /* not used ... */
                       int* global_offset) /*pos where current proc should start reading */
{
  int ncid, status, present_dims, dimid;
  MPI_Offset start_2d[2], count_2d[2], stride_2d[2];
  
  ncid = *file_identifier;

  /*Some of our old files used dim_NDIM as opposed to the current dim_MDIM
    Attempting to read in too much data will cause an abbort.*/
  if(ncmpi_inq_dimid(ncid, "dim_MDIM", &dimid))
    present_dims =  NDIM;
  else 
    present_dims = MDIM;

  printf("present_dims: %d", present_dims);

  start_2d[0] = (MPI_Offset) (*global_offset);
  start_2d[1] = 0;

  stride_2d[0] = 1;
  stride_2d[1] = 1;

  count_2d[0] = (MPI_Offset) (*local_blocks);
  count_2d[1] = present_dims;

  status = ncmpi_get_vars_double_all(ncid, *varid, start_2d, count_2d, stride_2d, coordinates);
  if (status < 0){
    printf("Error: ncmpi_get_vara_double_all, coordinates\n");
    Driver_abortFlashC("Error: ncmpi_get_vara_double_all, coordinates\n");
  }

#ifdef DEBUG_IO
        if (status != NC_NOERR)  handle_error(status);
#endif

}
