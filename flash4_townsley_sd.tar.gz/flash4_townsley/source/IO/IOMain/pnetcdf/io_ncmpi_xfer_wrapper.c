#include "io_ncmpi_xfer_wrapper.h"

int io_ncmpi_xfer_wrapper(const int myPE, const int fileID, const int xferType,
			  const char datasetName[], const int memType,
			  const int memSize[], const int memStart[],
			  const int memCount[], const int diskStart[],
			  const int diskCount[], const int dims, void * pData)
{
  MPI_Offset mpiDiskStart[IO_MAX_DIMS], mpiDiskCount[IO_MAX_DIMS],
    mpiMemCountScalar;
  MPI_Datatype mpiMemType;
  int varID, err, i;


  err = ncmpi_inq_varid(fileID, datasetName, &varID);
  if (err != NC_NOERR) {
    printf("[%s]: Processor %d unable to locate dataset %s.\n",
	   __FILE__, myPE, datasetName);
    Driver_abortFlashC("Unable to locate dataset");
  }

  mpiMemType = io_mpi_type_primitive(memType);


  /* Create arrays of type MPI_Offset describing myPE's portion in global data */
  mpiMemCountScalar = 1;
  for (i=0; i<dims; ++i) {
    if (diskStart[i] > 0 && diskCount[i] == 0) {
      /* Setting mpiDiskStart[i] to 0 stops an overly cautious index out of
	     bounds assertion error in pnetcdf library >= version 1.2.0pre1. */
	  mpiDiskStart[i] = 0;
    } else {
	  mpiDiskStart[i] = (MPI_Offset) diskStart[i];
    }
    mpiDiskCount[i] = (MPI_Offset) diskCount[i];
    mpiMemCountScalar *= (MPI_Offset) memCount[i];
  }


  /* Look at all dimension except index 0 because that is the slowest
     varying dimension.  As long as memsize and memcount are the same
     for all except the slowest varying dimension we are OK. */
  for (i=dims-1; i>0; --i) {
    if (memSize[i] != memCount[i]) {
      Driver_abortFlashC("Can only currently handle contiguous sections\n");
    }
  }

  
  /* We are only considering contiguous primitive data types so the
     memory count can be obtained by cycling through all dimensions */
  for (i=0; i<dims; ++i) {
    if (diskCount[i] != memCount[i] || memStart[i] != 0) {
      Driver_abortFlashC("Can only currently handle contiguous sections\n");
    }
  }


  err = io_ncmpi_xfer(myPE, fileID, xferType, varID,
		      mpiMemType, mpiMemCountScalar,
		      mpiDiskStart, mpiDiskCount, dims, pData);
  assert (err == 0);

  return 0;
}
