#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <pnetcdf.h>
#include "mangle_names.h"
#include <mpi.h>
#include <assert.h>
#include "Flash.h"
#include "constants.h"


int Driver_abortFlashC(char* message);

/*xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx*/

void FTOC(io_ncmpi_read_lrefine)(int* file_identifier,
                        int* varid,
                        int lrefine[],
                        int* local_blocks,
                        int* total_blocks,
                        int* global_offset)
{
  
  int ncid, status;
  
  MPI_Offset start_1d, count_1d;
  
  ncid = *file_identifier;
  
  start_1d = (MPI_Offset) (*global_offset);
  count_1d = (MPI_Offset) (*local_blocks);

  
  status = ncmpi_get_vara_int_all(ncid, *varid, &start_1d, &count_1d, lrefine);
  if (status < 0){
    printf("Error: ncmpi_get_vara_int_all, lrefine\n");
    Driver_abortFlashC("Error: ncmpi_get_vara_int_all, lrefine\n");
  }
  
#ifdef DEBUG_IO
        if (status != NC_NOERR)  handle_error(status);
#endif
      
}
