#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>
#include <pnetcdf.h>
#include "mangle_names.h"
#include <mpi.h>
#include "Flash.h"
#include "constants.h"


int Driver_abortFlashC(char* message);

/* xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx */

void FTOC(io_ncmpi_write_which_child)(int* file_identifier,
                   int* varid,
                   int which_child[],
                   int* local_blocks,
                   int* total_blocks,
                   int* global_offset)
{


  int ncid, status, nbytes;

  MPI_Offset start_1d, count_1d;

  ncid = *file_identifier;

  /* offset would be 0 if this were serial */

  start_1d = (MPI_Offset) (*global_offset);
  count_1d = (MPI_Offset) (*local_blocks);

  /* nbytes is size of int * the number of dimensions, in the case of 
     which_child there is only one dimension, num blocks
  */
  nbytes = (int)sizeof(int);
  /* it's local blocks here because it's mpi...*/


  /* High Level Data Mode */
  status = ncmpi_put_vara_int_all(ncid, *varid, &start_1d, &count_1d, which_child);

  /* flexible Data Mode Interface way 
  status = ncmpi_put_vara_all(ncid, *varid, &start_1d, &count_1d, 
                        (const void*)which_child, nbytes, MPI_INT);*/


  if (status < 0){
    printf("Error: ncmpi_put_vara_int_all, which_child\n");
    Driver_abortFlashC("Error: ncmpi_put_vara_int_all, which_child\n");
    
  }

#ifdef DEBUG_IO
        if (status != NC_NOERR)  handle_error(status);
#endif

}
