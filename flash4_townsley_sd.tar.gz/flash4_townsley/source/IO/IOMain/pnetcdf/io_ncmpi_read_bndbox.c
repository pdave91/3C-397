#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <pnetcdf.h>
#include "mangle_names.h"
#include <mpi.h>
#include <assert.h>
#include "Flash.h"
#include "constants.h"


int Driver_abortFlashC(char* message);

/*reads boundbox data from parallel netcdf file */

/* xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx */

void FTOC(io_ncmpi_read_bndbox)(int* file_identifier,  /* file handler */
                        int* varid,                 /* each var has id for efficiency */ 
                        double* bnd_box,           /* data to read */
                        int* local_blocks,         /* local number of blocks to read*/
                        int* total_blocks,        /* not used ... */
                        int* global_offset)      /*offset where current proc should start reading*/
{
  int ncid, status, present_dims, dimid;
  
  MPI_Offset start_3d[3], count_3d[3];
  
  ncid = *file_identifier;

  /*Some of our old files used dim_NDIM as opposed to the current dim_MDIM
    Attempting to read in too much data will cause an abbort.*/
  if(ncmpi_inq_dimid(ncid, "dim_MDIM", &dimid))
    present_dims =  NDIM;
  else 
    present_dims = MDIM;

  start_3d[0] = (MPI_Offset) (*global_offset);
  start_3d[1] = 0;
  start_3d[2] = 0;

      
  count_3d[0] = (MPI_Offset) (*local_blocks);
  count_3d[1] = present_dims; 
  count_3d[2] = 2;
  

   status = ncmpi_get_vara_double_all(ncid, *varid, start_3d, count_3d, bnd_box);
   if (status < 0){
     printf("Error: ncmpi_get_vara_double_all, bnd_box\n");
     Driver_abortFlashC("Error: ncmpi_get_vara_double_all, bnd_box\n");
   }
   
#ifdef DEBUG_IO
   if (status != NC_NOERR)  handle_error(status);
#endif
   
}
