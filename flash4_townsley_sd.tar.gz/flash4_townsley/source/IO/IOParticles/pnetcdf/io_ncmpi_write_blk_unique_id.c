#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>
#include <pnetcdf.h>
#include "mangle_names.h"
#include <mpi.h>
#include "Flash.h"
#include "constants.h"


int Driver_abortFlashC(char* message);




/* xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx */

void FTOC(io_ncmpi_write_blk_unique_id)(int* file_identifier,
				       int* varid,
				       int blk_unique_id[][MDIM],
				       int* local_blocks,
				       int* global_offset)
{
  int ncid, status;

  MPI_Offset start_2d[2], count_2d[2], stride_2d[2];

  ncid = *file_identifier;

  start_2d[0] = (MPI_Offset) (*global_offset);
  start_2d[1] = (MPI_Offset) 0;

  stride_2d[0] = (MPI_Offset)1;
  stride_2d[1] = (MPI_Offset)1;

  count_2d[0] = (MPI_Offset) (*local_blocks);
  count_2d[1] = (MPI_Offset) MDIM;  

  status = ncmpi_put_vars_int_all(ncid, *varid, start_2d, count_2d, stride_2d, blk_unique_id);
  if (status < 0){
    printf("Error: ncmpi_put_vars_int_all, blk uniqueid\n");
    Driver_abortFlashC("Error: ncmpi_put_vars_int_all, blk uniqueid\n");
    
  }
 

#ifdef DEBUG_IO
        if (status != NC_NOERR)  handle_error(status);
#endif

}
