#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>
#include <pnetcdf.h>
#include "mangle_names.h"
#include <mpi.h>
#include "Flash.h"
#include "constants.h"


int Driver_abortFlashC(char* message);


/* xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx */

void FTOC(io_ncmpi_read_particles)(int* file_identifier,
                           int* varid,
                           double* particles,
                           int* localnp,
                           int* npart_props, /* number of particle properties */
                           int* particle_offset)
{
  int ncid, status, rank;
  MPI_Offset start_2d[2], count_2d[2], stride_2d[2];

  ncid = *file_identifier;


  /* create the hyperslab -- this will differ on the different processors */
  start_2d[0] = (MPI_Offset) (*particle_offset);
  start_2d[1] = 0;
  
  count_2d[0] = (MPI_Offset) (*localnp);
  count_2d[1] = (MPI_Offset) (*npart_props);

  status = ncmpi_get_vara_double_all(ncid, *varid, start_2d, count_2d, particles);
  if (status < 0){
    printf("Error: ncmpi_get_vara_double_all, particles\n");
    Driver_abortFlashC("Error: ncmpi_get_vara_double_all, particles\n");
  }

#ifdef DEBUG_IO
  if (status != NC_NOERR)  handle_error(status);
#endif

}
