#include "bittree_bitarray.hxx"
#include "bittree_mortontree.hxx"
#include "bittree_ref.hxx"

#include "mpi.h"

using namespace BitTree;

typedef unsigned W;

namespace { // globals
  unsigned ndim = 0;
  Ref<MortonTree<1,W> > d1_tree;
  Ref<MortonTree<2,W> > d2_tree;
  Ref<MortonTree<3,W> > d3_tree;
  Ref<BitArray<W> > refine_delta;
}

extern "C" bool bittree_initialized() {
  return ndim > 0;
}

extern "C" void bittree_init(
    const int *ndim_,
    const int topsize[], // in: 0-based
    const bool includes[] // in: includes[topsize[ndim-1]]...[topsize[0]]
  ) {
  ndim = *ndim_;

  unsigned top[3];
  for(unsigned d=0; d < ndim; d++)
    top[d] = topsize[d];
  
  switch(ndim) {
  case 1:
    d1_tree = MortonTree<1,W>::make(top, includes);
    break;
  case 2:
    d2_tree = MortonTree<2,W>::make(top, includes);
    break;
  case 3:
    d3_tree = MortonTree<3,W>::make(top, includes);
    break;
  }
}

extern "C" void bittree_block_count(int *count) {
  DBG_ASSERT(0 < ndim && ndim <= 3);
  switch(ndim) {
  case 1: *count = d1_tree->blocks(); break;
  case 2: *count = d2_tree->blocks(); break;
  case 3: *count = d3_tree->blocks(); break;
  }
}

// given a level and ijk block position for that level, find the finest block
// that exactly matches or just contains that block position
extern "C" void bittree_morton(
    int *lev, // inout: 0-based
    int *ijk, // inout: 0-based
    int *mort // out: 0-based
  ) {
  DBG_ASSERT(0 < ndim && ndim <= 3);
  
  unsigned coord[3];
  for(unsigned d=0; d < ndim; d++)
    coord[d] = ijk[d];
  
  switch(ndim) {
  case 1:
    if(d1_tree->inside(*lev, coord)) {
      MortonTree<1,W>::Block<unsigned> b = d1_tree->identify(*lev, coord);
      *lev = b.level;
      ijk[0] = b.coord[0];
      *mort = b.mort;
    }
    else {
      *lev = -1;
      *mort = -1;
    }
    break;
  case 2:
    if(d2_tree->inside(*lev, coord)) {
      MortonTree<2,W>::Block<unsigned> b = d2_tree->identify(*lev, coord);
      *lev = b.level;
      ijk[0] = b.coord[0];
      ijk[1] = b.coord[1];
      *mort = b.mort;
    }
    else {
      *lev = -1;
      *mort = -1;
    }
    break;
  case 3:
    if(d3_tree->inside(*lev, coord)) {
      MortonTree<3,W>::Block<unsigned> b = d3_tree->identify(*lev, coord);
      *lev = b.level;
      ijk[0] = b.coord[0];
      ijk[1] = b.coord[1];
      ijk[2] = b.coord[2];
      *mort = b.mort;
    }
    else {
      *lev = -1;
      *mort = -1;
    }
    break;
  }
}

// how to refine/derefine a tree:
//   call bittree_refine_init
//   call bittree_refine_mark for every local block thats going to change
//   call bittree_refine_apply
// after that the tree corresponds to the new domain
extern "C" void bittree_refine_init() {
  if(ndim == 0) return;
  
  unsigned nbits;
  switch(ndim) {
  case 1: nbits = d1_tree->id_upper_bound(); break;
  case 2: nbits = d2_tree->id_upper_bound(); break;
  case 3: nbits = d3_tree->id_upper_bound(); break;
  }
  refine_delta = BitArray<W>::make(nbits);
  refine_delta->fill(false);
}

// mark block for nodetype change
extern "C" void bittree_refine_mark(
    const int *lev_, // in: 0-based
    const int *ijk // in: 0-based
  ) {
  if(ndim == 0) return;
  
  unsigned lev = unsigned(*lev_);
  unsigned coord[3];
  for(unsigned d=0; d < ndim; d++)
    coord[d] = ijk[d];

  unsigned id;
  switch(ndim) {
  case 1: id = d1_tree->identify(lev, coord).id; break;
  case 2: id = d2_tree->identify(lev, coord).id; break;
  case 3: id = d3_tree->identify(lev, coord).id; break;
  }
  refine_delta->set(id, true);
}

extern "C" void bittree_refine_apply(
    int *comm_
  ) {
  if(ndim == 0) return;
  
  MPI_Comm comm = MPI_Comm_f2c(*comm_);
  MPI_Allreduce(
    MPI_IN_PLACE,
    refine_delta->word_buf(),
    refine_delta->word_count(),
    MPI_UNSIGNED,
    MPI_BOR,
    comm
  );
  
  switch(ndim) {
  case 1:
    d1_tree = d1_tree->refine(refine_delta);
    break;
  case 2:
    d2_tree = d2_tree->refine(refine_delta);
    break;
  case 3:
    d3_tree = d3_tree->refine(refine_delta);
    break;
  }
  refine_delta.nullify();
}

#if 0
int main() {
  unsigned size[2] = {3,3};
  unsigned excl[1][2] = {1,1};
  Ref<MortonTree<2,unsigned> > tree = MortonTree<2,unsigned>::make(size, 1, excl);
  //for(int i=0; i < 10; i++) {
  for(int i=0; i < 3; i++) {
    Ref<BitArray<unsigned> > delta = BitArray<unsigned>::make(tree->level_id0(0) + tree->blocks());
    delta->fill(false, 0, tree->level_id0(tree->levels()-1));
    delta->fill(true, tree->level_id0(tree->levels()-1), tree->id_upper_bound());
    //delta->set(tree->level_id0(tree->levels()-1), true);
    //delta->set(tree->blocks()-1, true);
    tree = tree->refine(delta);
    cout << "i=" << i << " tree blocks=" << tree->blocks() << '\n';
  }
  if(false) {
    unsigned sum = 0;
    for(int i=0; i < 1<<14; i++) {
      unsigned x[2] = { i%(1<<11), i%(1<<11) };
      MortonTree<2,unsigned>::Block<unsigned> b0 = tree->identify(10, x);
      /*MortonTree<2,unsigned>::Block<unsigned> b1 = tree->locate<unsigned>(b0.id);
      DBG_ASSERT(b0.id == b1.id);
      DBG_ASSERT(b0.level == b1.level);
      DBG_ASSERT(b0.mort_ix == b1.mort_ix);
      DBG_ASSERT(b0.coord[0] == b1.coord[0] && b0.coord[1] == b1.coord[1]);
      */sum = 5*sum ^ b0.mort;
    }
    cout << "sum:" << sum << '\n';
  }
  else
    cout << (MortonTree<2,unsigned>*)tree;
}
#endif
