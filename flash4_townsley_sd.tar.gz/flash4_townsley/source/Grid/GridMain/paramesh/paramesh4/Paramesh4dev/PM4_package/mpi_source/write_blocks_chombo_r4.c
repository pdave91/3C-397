/* Stub function as a placeholder */  
/* To get functionality user must run INSTALL script in 
   utilities/io/plotting/chombo */
void write_blocks_chombo_r4(void) {
}
