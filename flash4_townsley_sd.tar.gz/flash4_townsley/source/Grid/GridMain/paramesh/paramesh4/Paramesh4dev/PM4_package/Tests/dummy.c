#include <stdio.h>
void dummy(void)
{
 int x;
 x = 0 ; x = x + x;
}

void abort_(void)
{
  abort();
}

void flush_(int *c)
{
  fflush(NULL);
}
