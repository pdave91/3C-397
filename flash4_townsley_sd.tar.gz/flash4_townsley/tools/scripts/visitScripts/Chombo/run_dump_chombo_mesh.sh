#!/bin/bash
visit -nowin -cli -assume_format Chombo -verbose -s dump_chombo_mesh.py
