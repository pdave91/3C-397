import os
import sys

if sys.version_info[0] == 3 or sys.version_info[:2] == (2, 7):
    import argparse
else:
    from .. import _argparse as argparse


# Command registration
#    key is command name, 
#    value is (command module - relative import, main function)
commands = {
    'setup': ('setup', 'main'),
    'build': ('build', 'main'),
    'run': ('run', 'main'),
    'restart': ('restart', 'main'),
    'merge': ('merge', 'main'),
    'clean': ('clean', 'main'),
    'metadata': ('metadata', 'main'),
    'diffpar': ('diffpar', 'main'),
    'ls-runs': ('lsruns', 'main'),
    'help': ('help_cmd', 'main'),
    'mv': ('mv', 'main'),
    'rm': ('rm', 'main'),
    'log': ('log', 'main'),
    'qsub': ('qsub', 'main'),
    'reproduce': ('reproduce', 'main'),
    }


def main(rcfile='flashrc.py', args=None):
    """Entry point for flash make utility."""
    # open run-control file, if present
    rc = {}
    if os.path.isfile(rcfile):
        execfile(rcfile, {}, rc)

    # Parse the command line arguments
    parser = _make_argparser()
    ns = parser.parse_args(args)
    if hasattr(ns, 'options'):
        ns.options = ns.options[1:] if ['--'] == ns.options[:1] else ns.options

    # Run the flmake command, use dynamic import
    if '.' not in sys.path:
        sys.path.insert(0, '.')
    cmdmod, mainfunc = commands[ns.cmd]
    cmdmod = __import__(cmdmod, globals(), locals(), fromlist=[None])
    mainfunc = getattr(cmdmod, mainfunc)
    rtn = mainfunc(ns, rc)

    # Handle some edge cases
    if rtn is NotImplemented:
        print "Command '{0}' has not yet been implemented.".format(cmd)
        raise SystemExit(1)
    elif 0 < rtn:
        print "flmake encountered an error."
        raise SystemExit(rtn)

    # remove empty flash.log
    if os.path.exists('flash.log') and 0 == os.path.getsize('flash.log'):
        os.remove('flash.log')


def _make_argparser():
    """Creates agrument parser for FLASH."""
    cmds = set()
    parser = argparse.ArgumentParser(description='FLASH make utility.', )
    subparsers = parser.add_subparsers(title='subcommands',
                                       description='valid subcommands',
                                       dest="cmd",
                                       help='sub-command help')

    # convenience addition functions
    add_message = lambda p: p.add_argument('-m', metavar="MESSAGE", default=None, 
                                           type=str, help='message to log', 
                                           required=False, dest="message")
    add_dry_run = lambda p: p.add_argument('--dry-run', default=False, action='store_true', 
                                           help='simulates running this command', 
                                           required=False, dest="dry_run")
    add_nprocs  = lambda p: p.add_argument('-n', '-np', '--n', '--np', '--nprocs',
                                           default=None, dest='nprocs')
    add_target  = lambda p: p.add_argument('-t', '--target', type=str, dest='target', 
                                           help='target dir name', default=None)
    add_source  = lambda p: p.add_argument('src', type=str, help='source file or dir')
    add_destin  = lambda p: p.add_argument('dst', type=str, help='destination file or dir')
    add_options = lambda p: p.add_argument('options', type=str, 
                                           nargs=argparse.REMAINDER, 
                                           help='build command to execute')


    # add build command
    cmds.add('build')
    subparser = subparsers.add_parser('build', prefix_chars="\0")
    add_options(subparser)

    # add run command
    cmds.add('run')
    subparser = subparsers.add_parser('run')
    add_nprocs(subparser)
    add_target(subparser)
    add_message(subparser)
    add_dry_run(subparser)
    add_options(subparser)

    # add restart command
    cmds.add('restart')
    subparser = subparsers.add_parser('restart')
    subparser.add_argument('prev_run', type=str, help='previous run dir or id')
    add_nprocs(subparser)
    add_target(subparser)
    add_message(subparser)
    add_dry_run(subparser)
    add_options(subparser)    

    # add merge command
    cmds.add('merge')
    subparser = subparsers.add_parser('merge')
    subparser.add_argument('leaf', type=str, help='leaf dir or id to merge')
    add_target(subparser)
    add_message(subparser)

    # add clean command
    cmds.add('clean')
    subparser = subparsers.add_parser('clean')
    subparser.add_argument('level', default=1, type=int, 
                           help='level of cleanliness')

    # add metadata command
    cmds.add('metadata')
    subparser = subparsers.add_parser('metadata')
    subparser.add_argument('-e', '--edit', default=False, action='store_true', 
                           dest='edit', help='level of cleanliness')

    # add metadata command
    cmds.add('diffpar')
    subparser = subparsers.add_parser('diffpar')
    subparser.add_argument('par1', help='first runtime parameters file')
    subparser.add_argument('par2', help='second runtime parameters file')

    # add mv command
    cmds.add('mv')
    subparser = subparsers.add_parser('mv')
    add_source(subparser)
    add_destin(subparser)
    add_message(subparser)

    # add rm command
    cmds.add('rm')
    subparser = subparsers.add_parser('rm')
    add_source(subparser)
    add_message(subparser)

    # add log command
    cmds.add('log')
    subparser = subparsers.add_parser('log')
    subparser.add_argument('-n', dest='n', type=int, default=None, 
                           help='number of log entries to display')

    # add qsub command
    cmds.add('qsub')
    subparser = subparsers.add_parser('qsub')#, prefix_chars="\0")
    subparser.add_argument("run_cmd", choices=['run', 'restart'], 
                           help="run command to submit to queue")
    add_message(subparser)
    add_options(subparser)    

    # add qsub command
    cmds.add('reproduce')
    subparser = subparsers.add_parser('reproduce')
    subparser.add_argument("desc", help="descrition file to reproduce")

    # add default parser for remaining commands
    for key in set(commands.keys()) - cmds:
        subparser = subparsers.add_parser(key)
        add_options(subparser)
    return parser
