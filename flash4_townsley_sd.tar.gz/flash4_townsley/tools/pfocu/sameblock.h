#include "options.h"

int sameblock(int dim, options_t *opts, 
	      FR_File *A, FR_File *B, int NA, int NB);
